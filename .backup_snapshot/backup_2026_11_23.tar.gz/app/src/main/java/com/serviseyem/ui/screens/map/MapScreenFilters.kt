package com.serviseyem.ui.screens.map

import com.serviseyem.data.PropertyEntity
import com.serviseyem.ui.*
import com.serviseyem.data.ProviderEntity
import com.serviseyem.data.StoreEntity
import com.serviseyem.ui.screens.map.components.MarkerRenderer
import com.serviseyem.utils.getPropertyCoords
import com.serviseyem.utils.getProviderCoords
import com.serviseyem.utils.getStoreCoords
import com.serviseyem.ui.screens.map.utils.CityAliases
import com.serviseyem.ui.screens.map.utils.MapDistanceCalculator
import com.serviseyem.ui.screens.home.extensions.*
import kotlin.math.cos
import kotlin.math.sin

/**
 * 🗺️ MapScreenFilters
 * Resilient filtering engine for Yemeni cities, categories, search queries, and Radar coordinates conversion.
 */
object MapScreenFilters {

    fun matchesCityFilter(
        cityFilter: String,
        entityCityId: String,
        entityArea: String,
        entityNeighborhood: String
    ): Boolean {
        if (cityFilter.isEmpty() || cityFilter == "الكل" || cityFilter == "جميع المدن والمحافظات") return true
        val normFilter = cityFilter.trim().lowercase()
        val combined = "$entityCityId $entityArea $entityNeighborhood".lowercase()

        val matchingKey = CityAliases.ALIASES.keys.find { normFilter.contains(it.lowercase()) }
        val aliases = if (matchingKey != null) CityAliases.ALIASES[matchingKey] ?: listOf(normFilter) else listOf(normFilter)

        return aliases.any { alias -> combined.contains(alias.lowercase()) }
    }

    fun filterProviders(
        providers: List<ProviderEntity>,
        selectedCategory: String,
        selectedCity: String,
        searchQuery: String
    ): List<ProviderEntity> {
        val cleanQuery = searchQuery.trim()
        val normQuery = com.serviseyem.ui.screens.map.utils.YemeniLocalSearchEngine.normalizeArabicText(cleanQuery)
        return providers.filter { p ->
            val matchesCat = selectedCategory == "ALL" || selectedCategory == "PROVIDERS"
            val matchesCity = matchesCityFilter(selectedCity, p.cityId, p.area, p.localNeighborhood)
            val matchesQuery = normQuery.isEmpty() || run {
                val combinedTarget = "${p.name} ${p.profession} ${p.customCategoryName} ${p.specialization} ${p.area} ${p.localNeighborhood}"
                com.serviseyem.ui.screens.map.utils.YemeniLocalSearchEngine.matchesDialectQuery(normQuery, combinedTarget)
            }
            matchesCat && matchesCity && matchesQuery
        }
    }

    fun filterStores(
        stores: List<StoreEntity>,
        selectedCategory: String,
        selectedCity: String,
        searchQuery: String
    ): List<StoreEntity> {
        val normQuery = com.serviseyem.ui.screens.map.utils.YemeniLocalSearchEngine.normalizeArabicText(searchQuery)
        return stores.filter { s ->
            val isMedical = s.isMedicalCenter()
            val isRestaurant = s.isRestaurantOrCafe()

            val matchesCat = when (selectedCategory) {
                "ALL" -> true
                "PROVIDERS" -> false
                "STORES" -> !isMedical && !isRestaurant
                "RESTAURANTS" -> isRestaurant
                "MEDICAL" -> isMedical
                else -> false
            }
            val matchesCity = matchesCityFilter(selectedCity, s.cityId, "", s.localNeighborhood)
            val matchesQuery = normQuery.isEmpty() || run {
                val combinedTarget = "${s.name} ${s.description} ${s.localNeighborhood} ${s.sectionId} ${s.categoryId}"
                com.serviseyem.ui.screens.map.utils.YemeniLocalSearchEngine.matchesDialectQuery(normQuery, combinedTarget)
            }
            matchesCat && matchesCity && matchesQuery
        }
    }

    fun filterProperties(
        properties: List<PropertyEntity>,
        selectedCategory: String,
        selectedCity: String,
        searchQuery: String
    ): List<PropertyEntity> {
        val normQuery = com.serviseyem.ui.screens.map.utils.YemeniLocalSearchEngine.normalizeArabicText(searchQuery)
        return properties.filter { pr ->
            val matchesCat = selectedCategory == "ALL" || selectedCategory == "PROPERTIES"
            val matchesCity = matchesCityFilter(selectedCity, pr.cityId, "", pr.localNeighborhood)
            val matchesQuery = normQuery.isEmpty() || run {
                val combinedTarget = "${pr.title} ${pr.description} ${pr.localNeighborhood}"
                com.serviseyem.ui.screens.map.utils.YemeniLocalSearchEngine.matchesDialectQuery(normQuery, combinedTarget)
            }
            matchesCat && matchesCity && matchesQuery
        }
    }

    fun buildRadarPoints(
        filteredProviders: List<ProviderEntity>,
        filteredStores: List<StoreEntity>,
        filteredProperties: List<PropertyEntity>,
        safeUserLat: Double,
        safeUserLng: Double
    ): List<MarkerRenderer.MapItemPoint> {
        val list = mutableListOf<MarkerRenderer.MapItemPoint>()

        filteredProviders.forEach { p ->
            val resolved = com.serviseyem.ui.screens.map.utils.MapCoordinateResolver.resolveProvider(p)
            val d = MapDistanceCalculator.calculateDistanceMeters(safeUserLat, safeUserLng, resolved.latitude, resolved.longitude)
            val bearing = com.serviseyem.ui.screens.map.utils.MapCoordinateResolver.calculateBearing(safeUserLat, safeUserLng, resolved.latitude, resolved.longitude)
            val r = (d / 1000.0).coerceIn(0.5, 30.0).toFloat() * 10f
            val rad = Math.toRadians(bearing.toDouble() - 90.0)
            list.add(
                MarkerRenderer.MapItemPoint(
                    id = p.id,
                    title = p.name,
                    type = "PROVIDER",
                    x = (r * cos(rad)).toFloat(),
                    y = (r * sin(rad)).toFloat(),
                    rating = p.rating.toDouble(),
                    isAvailable = p.isAvailable,
                    originalItem = p
                )
            )
        }

        filteredStores.forEach { s ->
            val resolved = com.serviseyem.ui.screens.map.utils.MapCoordinateResolver.resolveStore(s)
            val isMedical = s.isMedicalCenter()
            val isRestaurant = s.isRestaurantOrCafe()
            val typeStr = if (isMedical) "MEDICAL" else if (isRestaurant) "RESTAURANT" else "STORE"
            val d = MapDistanceCalculator.calculateDistanceMeters(safeUserLat, safeUserLng, resolved.latitude, resolved.longitude)
            val bearing = com.serviseyem.ui.screens.map.utils.MapCoordinateResolver.calculateBearing(safeUserLat, safeUserLng, resolved.latitude, resolved.longitude)
            val r = (d / 1000.0).coerceIn(0.5, 30.0).toFloat() * 10f
            val rad = Math.toRadians(bearing.toDouble() - 90.0)
            list.add(
                MarkerRenderer.MapItemPoint(
                    id = s.id,
                    title = s.name,
                    type = typeStr,
                    x = (r * cos(rad)).toFloat(),
                    y = (r * sin(rad)).toFloat(),
                    rating = s.rating.toDouble(),
                    isAvailable = s.isActive,
                    originalItem = s
                )
            )
        }

        filteredProperties.forEach { pr ->
            val resolved = com.serviseyem.ui.screens.map.utils.MapCoordinateResolver.resolveProperty(pr)
            val d = MapDistanceCalculator.calculateDistanceMeters(safeUserLat, safeUserLng, resolved.latitude, resolved.longitude)
            val bearing = com.serviseyem.ui.screens.map.utils.MapCoordinateResolver.calculateBearing(safeUserLat, safeUserLng, resolved.latitude, resolved.longitude)
            val r = (d / 1000.0).coerceIn(0.5, 30.0).toFloat() * 10f
            val rad = Math.toRadians(bearing.toDouble() - 90.0)
            list.add(
                MarkerRenderer.MapItemPoint(
                    id = pr.id,
                    title = pr.title,
                    type = "PROPERTY",
                    x = (r * cos(rad)).toFloat(),
                    y = (r * sin(rad)).toFloat(),
                    rating = 5.0,
                    isAvailable = pr.isActive,
                    originalItem = pr
                )
            )
        }
        return list
    }
}
