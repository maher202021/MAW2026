package com.serviseyem.ui.screens.map.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import com.serviseyem.data.PropertyEntity
import com.serviseyem.data.ProviderEntity
import com.serviseyem.data.StoreEntity
import com.serviseyem.ui.screens.map.utils.MapDistanceCalculator
import com.serviseyem.utils.CrossFuzzySearchEngine
import com.serviseyem.utils.OfflinePlacesDb
import com.serviseyem.utils.VisualThemePalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun VpsArCameraView(
    userLat: Double,
    userLng: Double,
    nearbyProviders: List<ProviderEntity>,
    nearbyStores: List<StoreEntity>,
    nearbyProperties: List<PropertyEntity>,
    onEntitySelected: (Any) -> Unit,
    onCloseAR: () -> Unit,
    themeColors: VisualThemePalette,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    // زر الرجوع في الهاتف يعيد المستخدم للخريطة مباشرة
    BackHandler {
        onCloseAR()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ar_radar")
    val radarPulse by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    val allNearby = remember(nearbyProviders, nearbyStores, nearbyProperties) {
        val list = mutableListOf<Triple<String, String, Any>>()
        nearbyProviders.take(5).forEach { list.add(Triple(it.name, "🛠️ فني", it)) }
        nearbyStores.take(5).forEach { list.add(Triple(it.name, "🏪 متجر", it)) }
        nearbyProperties.take(3).forEach { list.add(Triple(it.title, "🏢 عقار", it)) }
        list
    }

    // Real-time compass azimuth for AR bearing indicator
    var deviceAzimuth by remember { mutableFloatStateOf(0f) }
    DisposableEffect(context) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val rotSensor = sm?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val rotMatrix = FloatArray(9)
            private val orientation = FloatArray(3)
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                    SensorManager.getRotationMatrixFromVector(rotMatrix, event.values)
                    SensorManager.getOrientation(rotMatrix, orientation)
                    val deg = ((Math.toDegrees(orientation[0].toDouble()).toFloat() % 360f) + 360f) % 360f
                    if (abs(deg - deviceAzimuth) >= 2f) {
                        deviceAzimuth = deg
                    }
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sm != null && rotSensor != null) {
            sm.registerListener(listener, rotSensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose {
            sm?.unregisterListener(listener)
        }
    }

    val offlineNearestDb by produceState<String?>(initialValue = null, key1 = userLat, key2 = userLng) {
        if (userLat != 0.0 || userLng != 0.0) {
            value = withContext(Dispatchers.IO) { OfflinePlacesDb.nearest(context, userLat, userLng, 900.0) }
        }
    }

    val allLandmarks = remember(context) { CrossFuzzySearchEngine.getOrLoadLandmarks(context) }
    val facingLandmarkText = remember(userLat, userLng, deviceAzimuth, allLandmarks, offlineNearestDb) {
        val dirLabel = MapDistanceCalculator.cardinalDirectionAr(deviceAzimuth)
        if (userLat == 0.0 && userLng == 0.0) {
            "اتجاه البوصلة: $dirLabel (${deviceAzimuth.roundToInt()}°) • جارٍ تثبيت GPS"
        } else {
            val best = allLandmarks
                .map { lm ->
                    val dist = MapDistanceCalculator.calculateDistanceMeters(userLat, userLng, lm.lat, lm.lng)
                    val bearing = MapDistanceCalculator.calculateBearingDegrees(userLat, userLng, lm.lat, lm.lng)
                    val diff = abs(((bearing - deviceAzimuth + 540f) % 360f) - 180f)
                    Triple(lm, dist, diff)
                }
                .minByOrNull { (_, dist, diff) -> dist + diff * 18.0 }

            when {
                best != null && best.second < 15_000 -> {
                    val distStr = MapDistanceCalculator.formatDistance(best.second)
                    val lmDir = MapDistanceCalculator.cardinalDirectionAr(
                        MapDistanceCalculator.calculateBearingDegrees(userLat, userLng, best.first.lat, best.first.lng)
                    )
                    "${best.first.name} (${best.first.city}) • $distStr نحو $lmDir"
                }
                !offlineNearestDb.isNullOrBlank() -> "$offlineNearestDb • اتجاه $dirLabel (${deviceAzimuth.roundToInt()}°)"
                else -> "اتجاه الكاميرا: $dirLabel (${deviceAzimuth.roundToInt()}°)"
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF030712))
    ) {
        // Real Live Camera Feed via CameraX
        if (hasCameraPermission) {
            var cameraProviderInstance by remember { mutableStateOf<ProcessCameraProvider?>(null) }
            DisposableEffect(lifecycleOwner) {
                onDispose {
                    try {
                        cameraProviderInstance?.unbindAll()
                    } catch (e: Exception) {}
                }
            }

            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    }
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    val executor = ContextCompat.getMainExecutor(ctx)
                    cameraProviderFuture.addListener({
                        try {
                            val provider = cameraProviderFuture.get()
                            cameraProviderInstance = provider
                            provider.unbindAll()
                            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                            val preview = Preview.Builder().build().also {
                                it.setSurfaceProvider(previewView.surfaceProvider)
                            }
                            provider.bindToLifecycle(lifecycleOwner, cameraSelector, preview)
                        } catch (e: Exception) {
                            // Safe fallback: keeps canvas radar visible
                        }
                    }, executor)
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )

            // Semi-transparent HUD overlay to keep text and cyber radar clearly readable
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x66030712))
            )
        }

        // AR Scanning Background & Radar Grid
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 1.4f

            // Radar rings
            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                radius = maxRadius * 0.35f,
                center = center,
                style = Stroke(width = 1.5f)
            )
            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = 0.25f),
                radius = maxRadius * 0.70f,
                center = center,
                style = Stroke(width = 1.5f)
            )
            drawCircle(
                color = Color(0xFF10B981).copy(alpha = (1.0f - radarPulse) * 0.4f),
                radius = maxRadius * radarPulse,
                center = center,
                style = Stroke(width = 2.5f)
            )

            // Crosshairs
            drawLine(
                color = Color(0x3300E5FF),
                start = Offset(center.x, center.y - maxRadius),
                end = Offset(center.x, center.y + maxRadius),
                strokeWidth = 1f
            )
            drawLine(
                color = Color(0x3300E5FF),
                start = Offset(center.x - maxRadius, center.y),
                end = Offset(center.x + maxRadius, center.y),
                strokeWidth = 1f
            )
        }

        // Top Control Header Bar
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xF00F172A), Color(0xCC0F172A), Color.Transparent)
                    )
                )
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back Button
                Button(
                    onClick = onCloseAR,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.defaultMinSize(minHeight = 48.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الرجوع للخريطة 🗺️",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // AR Status Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF0F242A),
                    border = BorderStroke(1.dp, Color(0xFF10B981))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "وضع الواقع المعزز (VPS)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Subtitle status
            Text(
                text = "جارٍ مسح البيئة المحيطة لتحديد مواقع الفنيين والمحلات القريبة بدقة...",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Center Content & AR Target Markers
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Camera permission notice if needed
            if (!hasCameraPermission) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xDD1E293B)),
                    border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "للحصول على رؤية حية لمواقع الخدمات عبر كاميرا هاتفك:",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("منح الإذن 📷", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { onCloseAR() },
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("العودة لـ 3D 🏙️", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Stats Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xAA0F172A)),
                border = BorderStroke(1.dp, Color(0x33FFFFFF))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Explore,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "عدد الخدمات المكتشفة في محيطك",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${allNearby.size} خدمة متوفرة بالقرب منك",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // AR Dynamic Landmark & Compass Bearing Overlay
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B).copy(alpha = 0.9f),
                border = BorderStroke(1.2.dp, Color(0xFF10B981))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Place,
                        contentDescription = null,
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = "المعلم المقابل للكاميرا والبوصلة 🎯",
                            color = Color(0xFF10B981),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = facingLandmarkText,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Bottom Bar: Nearby Entities List + Big Return Button
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xEE0F172A), Color(0xFF0F172A))
                    )
                )
                .navigationBarsPadding()
                .padding(bottom = 16.dp, start = 14.dp, end = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Horizontal list of nearby services in AR
            if (allNearby.isNotEmpty()) {
                Text(
                    text = "الخدمات المكتشفة على الرادار:",
                    color = Color(0xFF00E5FF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(allNearby) { item ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1E293B),
                            border = BorderStroke(1.dp, Color(0x4400E5FF)),
                            modifier = Modifier
                                .clickable {
                                    onEntitySelected(item.third)
                                    onCloseAR()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(item.second, fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(item.first, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Big Return Button
            Button(
                onClick = onCloseAR,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Map,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "العودة إلى خريطة اليمن الكاملة 🗺️",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}
